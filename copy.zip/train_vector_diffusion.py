#!/usr/bin/env python
"""Train latent stroke diffusion after a real-data autoencoder checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch
import torch.nn.functional as F
from diffusers import DDPMScheduler
from torch.utils.data import DataLoader, TensorDataset

try:
    from .model import StrokeAutoencoder, StrokeLatentDiffusion, diffusion_loss
    from .geometry import clothoid_bbox, place_clothoids
    from .render import render_strokes
    from .vector_data import SVGClothoidDataset
except ImportError:  # direct execution from inside hybrid_stroke_diffusion/
    from model import StrokeAutoencoder, StrokeLatentDiffusion, diffusion_loss
    from geometry import clothoid_bbox, place_clothoids
    from render import render_strokes
    from vector_data import SVGClothoidDataset


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--ae-checkpoint", required=True)
    ap.add_argument("--max-strokes", type=int, default=64)
    ap.add_argument("--segment-points", type=int, default=16)
    ap.add_argument("--limit", type=int, default=20000)
    ap.add_argument("--steps", type=int, default=20000)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--num-workers", type=int, default=0)
    ap.add_argument("--cache-file", default="", help=".pt cache produced by train_vector_ae --cache-only")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--out-dir", default="runs/hybrid_vector_diffusion_tu_berlin")
    ap.add_argument("--resume", default="", help="load an existing denoiser checkpoint before training/preview")
    ap.add_argument("--conditioned", action="store_true", help="condition on SVG parent category")
    ap.add_argument("--udf-dim", type=int, default=64)
    ap.add_argument("--preview-samples", type=int, default=4)
    ap.add_argument("--preview-steps", type=int, default=1000)
    ap.add_argument("--log-every", type=int, default=100)
    args = ap.parse_args()
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise SystemExit("CUDA unavailable")
    device = torch.device(args.device)
    if args.cache_file:
        cache = torch.load(args.cache_file, map_location="cpu", weights_only=False)
        meta = cache.get("meta", {})
        if meta.get("max_strokes") != args.max_strokes or meta.get("segment_points") != args.segment_points:
            raise SystemExit(f"cache configuration mismatch: {meta}")
        expected_n = min(args.limit, int(meta.get("n", args.limit)))
        if int(meta.get("n", -1)) != expected_n:
            raise SystemExit(
                f"cache/data mismatch: --limit={args.limit}, cache contains {meta.get('n')} samples. "
                "Use a distinct cache-file or rerun cache-only."
            )
        ds = TensorDataset(cache["params"].float(), cache["valid"].float())
        labels = cache.get("labels")
        categories = cache.get("categories", [])
        print(f"loaded parsed vector cache: {args.cache_file} ({len(ds)} samples)", flush=True)
    else:
        ds = SVGClothoidDataset(args.data, args.max_strokes, segment_points=args.segment_points, limit=args.limit)
        labels = None; categories = []
    if args.conditioned and labels is None:
        raise SystemExit("--conditioned requires a cache built by the updated train_vector_ae")
    if args.conditioned and len(categories) == 0:
        raise SystemExit("conditioned cache has no categories")
    if args.conditioned:
        ds = TensorDataset(ds.tensors[0], ds.tensors[1], labels.long())
    loader = DataLoader(
        ds, batch_size=args.batch, shuffle=True, num_workers=args.num_workers,
        pin_memory=device.type == "cuda", persistent_workers=args.num_workers > 0,
    )
    ae = StrokeAutoencoder(latent_dim=64, hidden=128, udf_dim=args.udf_dim).to(device)
    state = torch.load(args.ae_checkpoint, map_location=device, weights_only=False)
    ae.load_state_dict(state["model"], strict=True); ae.eval()
    for p in ae.parameters(): p.requires_grad_(False)
    cond_dim = len(categories) if args.conditioned else 0
    # Joint state: shape latent (64) + geometric bbox (4) + presence (1).
    state_dim = 69
    denoiser = StrokeLatentDiffusion(latent_dim=state_dim, model_dim=128, layers=4, heads=4, cond_dim=cond_dim, use_pos=True).to(device)
    if args.resume:
        saved = torch.load(args.resume, map_location=device, weights_only=False)
        denoiser.load_state_dict(saved["model"], strict=True)
        print(f"loaded diffusion checkpoint: {args.resume}", flush=True)
    opt = torch.optim.AdamW(denoiser.parameters(), lr=2e-4, weight_decay=1e-4)
    scheduler = DDPMScheduler(num_train_timesteps=1000, beta_schedule="linear", clip_sample=False)
    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    it = iter(loader); history = []
    metrics_path = out / "train_metrics.jsonl"
    for step in range(1, args.steps + 1):
        try: batch = next(it)
        except StopIteration: it = iter(loader); batch = next(it)
        if args.conditioned:
            params, valid, labels_batch = batch
            cond = F.one_hot(labels_batch.to(device), num_classes=cond_dim).float()
        else:
            params, valid = batch; cond = None
        params, valid = params.to(device), valid.to(device)
        # Strokes are a set, not a sentence.  Randomize their order every
        # update so the denoiser cannot memorize the preprocessing order.
        perm = torch.argsort(torch.rand(params.shape[0], params.shape[1], device=device), dim=1)
        gather = perm[..., None].expand(-1, -1, params.shape[-1])
        params = params.gather(1, gather)
        valid = valid.gather(1, perm)
        with torch.no_grad():
            z = ae.encode(params)
            bbox = clothoid_bbox(params)
            # Match the reference DDPM convention: inactive=-1, active=+1.
            # A 0/1 presence channel is biased positive after denoising and
            # makes nearly every generated stroke appear active.
            # Match StrokeFusion's convention exactly: active=+0.5,
            # padded=-0.5.  Using +/-1 makes the final DDPM step strongly
            # biased toward the positive state channel.
            clean = torch.cat((z, bbox, (valid - 0.5)[..., None]), -1)
        t = torch.randint(0, scheduler.config.num_train_timesteps, (clean.shape[0],), device=device).long()
        noise = torch.randn_like(clean)
        noisy = scheduler.add_noise(clean, noise, t)
        pred_noise, count_pred = denoiser(noisy, t, cond, return_count=True)
        err = (pred_noise - noise).square()
        active = valid[..., None].expand_as(err).clone()
        active[..., 68] = 1.0
        noise_loss = (err * active).sum() / active.sum().clamp_min(1.0)
        count_target = valid.sum(-1).float() / float(args.max_strokes)
        count_loss = F.mse_loss(torch.sigmoid(count_pred), count_target)
        loss = noise_loss + 0.25 * count_loss
        opt.zero_grad(set_to_none=True); loss.backward()
        grad_norm = float(torch.nn.utils.clip_grad_norm_(denoiser.parameters(), 1.0)); opt.step()
        if step == 1 or step % args.log_every == 0 or step == args.steps:
            with torch.no_grad():
                # Reconstruct x0 from the predicted noise at this timestep.
                abar = scheduler.alphas_cumprod[t].to(device)[:, None, None]
                x0_hat = (noisy - (1.0 - abar).sqrt() * pred_noise) / abar.sqrt().clamp_min(1e-4)
                active_shape = valid[..., None].expand_as(err).clone()
                active_shape[..., 68] = 0
                active_n = active_shape.sum().clamp_min(1.0)
                inactive_mask = (1.0 - valid)[..., None].expand_as(err).clone()
                inactive_mask[..., 68] = 1.0
                inactive_n = inactive_mask.sum().clamp_min(1.0)
                presence_target = clean[..., 68]
                presence_hat = x0_hat[..., 68]
                count_prob = torch.sigmoid(count_pred)
                count_target = valid.sum(-1).float() / float(args.max_strokes)
                row = {
                "step": step, "diffusion_loss": float(loss), "noise_loss": float(noise_loss), "count_loss": float(count_loss), "t_mean": float(t.float().mean()),
                    "noise_mse_active": float((err * active_shape).sum() / active_n),
                    "noise_mse_inactive": float((err * inactive_mask).sum() / inactive_n),
                    "x0_shape_mse": float(((((x0_hat[..., :64] - clean[..., :64]).square()) * valid[..., None]).sum() / valid.sum().clamp_min(1.0) / 64)),
                    "x0_bbox_mse": float(((((x0_hat[..., 64:68] - clean[..., 64:68]).square()) * valid[..., None]).sum() / valid.sum().clamp_min(1.0) / 4)),
                    "presence_sign_acc": float((presence_hat.sign() == presence_target.sign()).float().mean()),
                    "presence_active_recall": float((presence_hat[valid > .5] > 0).float().mean()) if (valid > .5).any() else 0.0,
                    "presence_inactive_rejection": float((presence_hat[valid <= .5] < 0).float().mean()) if (valid <= .5).any() else 0.0,
                    "active_count_mean": float(valid.sum(-1).mean()),
                    "predicted_count_mean": float((count_prob * args.max_strokes).mean()),
                    "count_mae": float((count_prob - count_target).abs().mean() * args.max_strokes),
                    "grad_norm": grad_norm,
                }
            history.append(row)
            with metrics_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(row) + "\n")
            print(json.dumps(row), flush=True)
            if step % 500 == 0 or step == args.steps or step == 1:
                torch.save({"model": denoiser.state_dict(), "ae_checkpoint": args.ae_checkpoint, "config": vars(args), "history": history}, out / "latest.pt")

    # Unconditional latent sampling preview.  This is deliberately done only
    # once after training; it is not part of the optimization loop.
    denoiser.eval()
    with torch.no_grad():
        n = max(1, args.preview_samples)
        steps = max(2, args.preview_steps)
        if steps < 1000:
            print("WARNING: preview_steps<1000 is an accelerated diagnostic and can collapse presence; use 1000 for final sampling.", flush=True)
        length = args.max_strokes
        x = torch.randn(n, length, state_dim, device=device)
        preview_cond = None
        if args.conditioned:
            preview_labels = torch.arange(n, device=device) % cond_dim
            preview_cond = F.one_hot(preview_labels, num_classes=cond_dim).float()
        scheduler.set_timesteps(steps, device=device)
        presence_trace = []
        for t in scheduler.timesteps:
            tt = torch.full((n,), int(t), device=device, dtype=torch.long)
            eps, count_pred = denoiser(x, tt, preview_cond, return_count=True)
            count_est = (torch.sigmoid(count_pred) * args.max_strokes).clamp(1, args.max_strokes).round().long()
            x = scheduler.step(eps, t, x).prev_sample
            if len(presence_trace) < 5 or int(t) < 10:
                presence_trace.append({"t": int(t), "mean": float(x[..., 68].mean()),
                                       "min": float(x[..., 68].min()), "max": float(x[..., 68].max()),
                                       "positive_fraction": float((x[..., 68] > 0).float().mean())})
        # Presence is now generated by diffusion, not guessed by the AE.
        # Use the learned global count to prevent the permutation-invariant
        # presence channel from selecting every padded token.
        # Use only the learned global count.  No dataset-average fallback:
        # cardinality must be inferred from the generated state/condition.
        k = int(count_est.float().median().clamp(1, args.max_strokes).round().item())
        scores = x[..., 68]
        top = scores.topk(k, dim=-1).indices
        generated_valid = torch.zeros_like(scores)
        generated_valid.scatter_(1, top, 1.0)
        generated, _ = ae.decode(x[..., :64])
        generated = place_clothoids(generated, x[..., 64:68])
        import matplotlib.pyplot as plt
        imgs = render_strokes(generated, generated_valid, size=192, curve_samples=32).clamp(0, 1).cpu()
        # Include an actual dataset example and its AE reconstruction in the
        # same diagnostic image.  Otherwise a diffusion preview alone cannot
        # distinguish a bad AE from a bad sampler.
        target_item = ds[0]
        target_params, target_valid = target_item[:2]
        target_params = target_params[None].to(device)
        target_valid = target_valid[None].to(device)
        target_recon, target_logits, _ = ae(target_params)
        target_img = render_strokes(target_params, target_valid, size=192, curve_samples=32).clamp(0, 1).cpu()[0]
        recon_valid = (target_logits > 0.0).float()
        recon_img = render_strokes(target_recon, recon_valid, size=192, curve_samples=32).clamp(0, 1).cpu()[0]
        cols = min(4, n)
        rows = (n + cols - 1) // cols + 1
        fig, axes = plt.subplots(rows, cols, figsize=(3 * cols, 3 * rows), squeeze=False)
        axes[0, 0].imshow(target_img); axes[0, 0].set_title("target SVG")
        if cols > 1:
            axes[0, 1].imshow(recon_img); axes[0, 1].set_title("AE reconstruction")
        for c in range(2, cols):
            axes[0, c].axis("off")
        for i, ax in enumerate(axes.flat[cols:]):
            ax.axis("off")
            if i < n:
                ax.imshow(imgs[i])
                ax.set_title(f"sample {i + 1}")
        fig.tight_layout()
        fig.savefig(out / "preview_generated_vectors.png", dpi=140)
        fig.savefig(out / "preview_target_reconstruction_generated.png", dpi=140)
        plt.close(fig)
        print(f"preview -> {out / 'preview_generated_vectors.png'}", flush=True)
        print(json.dumps({"generated_active_mean": float(generated_valid.sum(-1).float().mean()),
                          "generated_active_min": int(generated_valid.sum(-1).min()),
                          "generated_active_max": int(generated_valid.sum(-1).max()),
                          "generated_count_estimate": k,
                          "presence_trace": presence_trace}), flush=True)


if __name__ == "__main__":
    main()
